from Homework15.view.main_view import main

if __name__ == "__main__":
    main()
