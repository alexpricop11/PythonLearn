# {'email': str, 'password': str}

USERS_DATABASE = []
POSTS_DATABASE = []
